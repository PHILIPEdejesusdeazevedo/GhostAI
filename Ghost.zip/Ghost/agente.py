# -*- coding: utf-8 -*-
"""
GhostAI - Agente autonomo no Google Colab
- Interface Gradio (upload de ZIP do Sketchware Pro, chat, analise de arquivos)
- Ollama com 2 modelos: qwen-sketchware (Qwen2.5-Coder-7B) + deepseek-fix (DeepSeek-Coder-6.7B)
- Pesquisa autonoma via SearXNG local (API JSON) com fallback DuckDuckGo + GitHub
- Memoria permanente em SQLite (nunca esquece conversas)
- Executa comandos Linux (curl, wget, unzip, gradle build) com saida ao vivo
- Gera link de download do codigo corrigido

Uso no Colab: rode o notebook Ghost.ipynb (ele instala tudo e sobe esta interface).
"""

import os, re, json, zipfile, shutil, sqlite3, subprocess, threading, datetime, textwrap
import requests
import gradio as gr

# ---------------- Config ----------------
OLLAMA_URL   = os.environ.get("OLLAMA_URL", "http://127.0.0.1:11434")
SEARX_URL    = os.environ.get("SEARX_URL", "http://127.0.0.1:8888")
MODELO_MAIN  = "qwen-sketchware"    # ou "qwen2.5-coder:7b"
MODELO_FIX   = "deepseek-fix"       # ou "deepseek-coder:6.7b"
WORK         = "/content/work"
PROJETO      = os.path.join(WORK, "projeto")
DB           = os.path.join(WORK, "memoria.db")
os.makedirs(PROJETO, exist_ok=True)

# ---------------- Memoria permanente ----------------
def db():
    conn = sqlite3.connect(DB)
    conn.execute("""CREATE TABLE IF NOT EXISTS memoria(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        ts TEXT, papel TEXT, conteudo TEXT)""")
    conn.execute("""CREATE TABLE IF NOT EXISTS fatos(
        chave TEXT PRIMARY KEY, valor TEXT, ts TEXT)""")
    return conn

def lembrar(papel, conteudo):
    conn = db()
    conn.execute("INSERT INTO memoria(ts,papel,conteudo) VALUES(?,?,?)",
                 (datetime.datetime.now().isoformat(), papel, conteudo))
    conn.commit(); conn.close()

def historico(limite=30):
    conn = db()
    rows = conn.execute("SELECT papel,conteudo FROM memoria ORDER BY id DESC LIMIT ?", (limite,)).fetchall()
    conn.close()
    return list(reversed(rows))

def gravar_fato(chave, valor):
    conn = db()
    conn.execute("INSERT OR REPLACE INTO fatos VALUES(?,?,?)",
                 (chave, valor, datetime.datetime.now().isoformat()))
    conn.commit(); conn.close()

# ---------------- LLM via Ollama ----------------
def llm(mensagem, modelo=MODELO_MAIN, system_extra=""):
    agora = datetime.datetime.now().strftime("%d/%m/%Y %H:%M:%S")
    system = (f"Data/hora atual do mundo: {agora}. Responda em pt-BR. "
              f"Seja direto, nao faca perguntas, execute. " + system_extra)
    msgs = [{"role": "system", "content": system}]
    for papel, conteudo in historico():
        msgs.append({"role": "user" if papel == "user" else "assistant", "content": conteudo[:4000]})
    msgs.append({"role": "user", "content": mensagem})
    r = requests.post(f"{OLLAMA_URL}/api/chat",
                      json={"model": modelo, "messages": msgs, "stream": False},
                      timeout=900)
    resp = r.json()["message"]["content"]
    lembrar("user", mensagem); lembrar("assistant", resp)
    return resp

# ---------------- Pesquisa autonoma (SearXNG JSON + fallback DuckDuckGo) ----------------
def pesquisar(query, n=6):
    # 1) tenta SearXNG local
    try:
        r = requests.get(f"{SEARX_URL}/search",
                         params={"q": query, "format": "json"}, timeout=20)
        dados = r.json()
        out = []
        for res in dados.get("results", [])[:n]:
            out.append(f"- {res.get('title')}\n  {res.get('url')}\n  {res.get('content','')[:300]}")
        if out:
            return "\n".join(out)
    except Exception:
        pass
    # 2) fallback: DuckDuckGo (nao precisa de servidor)
    try:
        from duckduckgo_search import DDGS
        with DDGS() as ddgs:
            resultados = list(ddgs.text(query, max_results=n))
        if resultados:
            return "\n".join(f"- {r.get('title')}\n  {r.get('href')}\n  {r.get('body','')[:300]}"
                             for r in resultados)
        return "Sem resultados."
    except Exception as e:
        return f"Pesquisa indisponivel ({e})."

def github_buscar(query, n=5):
    try:
        r = requests.get("https://api.github.com/search/repositories",
                         params={"q": query, "sort": "updated", "per_page": n},
                         headers={"Accept": "application/vnd.github+json"}, timeout=30)
        return "\n".join(f"- {i['full_name']} ⭐{i['stargazers_count']}\n  {i['html_url']}\n  {i.get('description','')}"
                         for i in r.json().get("items", []))
    except Exception as e:
        return f"GitHub indisponivel ({e})."

# ---------------- Comandos Linux ----------------
def bash(cmd):
    try:
        p = subprocess.run(cmd, shell=True, capture_output=True, text=True,
                           cwd=PROJETO, timeout=600)
        return (p.stdout + p.stderr)[-6000:]
    except subprocess.TimeoutExpired:
        return "⏱️ Comando estourou o tempo limite (600s)."

# ---------------- ZIP do Sketchware ----------------
def subir_zip(arquivo):
    if arquivo is None:
        return "Envie um ZIP."
    shutil.rmtree(PROJETO, ignore_errors=True); os.makedirs(PROJETO, exist_ok=True)
    with zipfile.ZipFile(arquivo.name) as z:
        z.extractall(PROJETO)
    raiz = os.listdir(PROJETO)
    if len(raiz) == 1 and os.path.isdir(os.path.join(PROJETO, raiz[0])):
        inner = os.path.join(PROJETO, raiz[0])
        for f in os.listdir(inner):
            shutil.move(os.path.join(inner, f), PROJETO)
        os.rmdir(inner)
    tree = bash("find . -maxdepth 2 -type d | head -40")
    gravar_fato("ultimo_zip", arquivo.name)
    return f"✅ Projeto extraido de `{os.path.basename(arquivo.name)}`:\n```\n{tree}\n```"

def listar_arquivos():
    return "```\n" + bash("find . -type f \\( -name '*.java' -o -name '*.gradle' -o -name '*.xml' \\) | head -200") + "\n```"

def ler_arquivo(path):
    full = os.path.join(PROJETO, path)
    if not os.path.isfile(full):
        return "Arquivo nao encontrado."
    return "```\n" + open(full, encoding="utf-8", errors="replace").read()[:15000] + "\n```"

def escrever_arquivo(path, conteudo):
    full = os.path.join(PROJETO, path)
    os.makedirs(os.path.dirname(full), exist_ok=True)
    open(full, "w", encoding="utf-8").write(conteudo)
    return f"✅ Salvo: {path}"

# ---------------- Namespace do projeto ----------------
def descobrir_namespace():
    """Pega o package do AndroidManifest; fallback com.sketchware.remod."""
    for raiz, _, arqs in os.walk(PROJETO):
        if "AndroidManifest.xml" in arqs:
            t = open(os.path.join(raiz, "AndroidManifest.xml"),
                     encoding="utf-8", errors="replace").read()
            m = re.search(r'package="([^"]+)"', t)
            if m:
                return m.group(1)
    return "com.sketchware.remod"

# ---------------- Correcao automatica Java 17 / SDK 34 ----------------
def corrigir_projeto():
    relatorio = []
    ns = descobrir_namespace()
    # 1) build.gradle de todos os modulos
    for raiz, _, arqs in os.walk(PROJETO):
        for a in arqs:
            if a in ("build.gradle", "build.gradle.kts"):
                p = os.path.join(raiz, a)
                t = open(p, encoding="utf-8", errors="replace").read()
                orig = t
                t = re.sub(r"compileSdkVersion\s+\d+", "compileSdk 34", t)
                t = re.sub(r"targetSdkVersion\s+\d+", "targetSdk 34", t)
                t = re.sub(r"minSdkVersion\s+(\d+)", lambda m: f"minSdk {max(int(m.group(1)),24)}", t)
                t = re.sub(r"sourceCompatibility\s+.*", "sourceCompatibility JavaVersion.VERSION_17", t)
                t = re.sub(r"targetCompatibility\s+.*", "targetCompatibility JavaVersion.VERSION_17", t)
                t = t.replace("jcenter()", "mavenCentral()")
                if "namespace" not in t and "com.android.application" in t:
                    t = t.replace("android {", f"android {{\n    namespace '{ns}'", 1)
                if t != orig:
                    open(p, "w", encoding="utf-8").write(t)
                    relatorio.append(f"✏️ {os.path.relpath(p, PROJETO)} atualizado para SDK 34 / Java 17 (namespace {ns})")
    # 2) gradle-wrapper e AGP
    props = bash("find . -name gradle-wrapper.properties")
    relatorio.append(f"Gradle wrapper:\n{props}")
    # 3) AndroidManifest: android:exported
    for raiz, _, arqs in os.walk(PROJETO):
        for a in arqs:
            if a == "AndroidManifest.xml":
                p = os.path.join(raiz, a)
                t = open(p, encoding="utf-8", errors="replace").read()
                novo = re.sub(r"<(activity|receiver|service)([^>]*?android:name=\"[^\"]+\")(?![^>]*android:exported)",
                              r'<\1\2 android:exported="true"', t)
                if novo != t:
                    open(p, "w", encoding="utf-8").write(novo)
                    relatorio.append(f"✏️ {os.path.relpath(p, PROJETO)}: android:exported adicionado")
    # 4) Revisao pela IA dos arquivos criticos
    criticos = bash("find . -name 'build.gradle' -o -name 'settings.gradle' | head -5")
    analise = llm(f"Revise estes arquivos Gradle apos migracao para Java 17/SDK 34 e aponte o que falta:\n{criticos}\n\nConteudo:\n{bash('cat $(find . -name build.gradle | head -3)')[:8000]}",
                  modelo=MODELO_FIX)
    relatorio.append("🤖 Revisao da IA:\n" + analise)
    return "\n\n".join(relatorio) if relatorio else "Nada a corrigir."

# ---------------- Build + loop de erros ----------------
def build_e_corrigir():
    log = bash("chmod +x gradlew 2>/dev/null; ./gradlew assembleDebug --stacktrace 2>&1 | tail -120")
    if "BUILD SUCCESSFUL" in log:
        return "✅ BUILD SUCCESSFUL\n```\n" + log[-3000:] + "\n```"
    solucao = llm(f"Este build falhou. De a causa raiz e o patch exato (arquivo + conteudo corrigido):\n```\n{log}\n```",
                  modelo=MODELO_FIX)
    pesquisa = pesquisar("android build error " + " ".join(log.splitlines()[-5:])[:150])
    return f"❌ Build falhou.\n\n**Log:**\n```\n{log[-3000:]}\n```\n\n**Diagnostico da IA:**\n{solucao}\n\n**Pesquisa web:**\n{pesquisa}"

# ---------------- Download do codigo corrigido ----------------
def gerar_zip():
    saida = "/content/sketchware_corrigido.zip"
    shutil.make_archive(saida.replace(".zip", ""), "zip", PROJETO)
    return saida

# ---------------- Chat autonomo ----------------
PESQUISA = re.compile(r"^\s*/pesquisa\s+(.+)")
GIT      = re.compile(r"^\s*/github\s+(.+)")
CMD      = re.compile(r"^\s*/cmd\s+(.+)")
LER      = re.compile(r"^\s*/ler\s+(.+)")
GRAVAR   = re.compile(r"^\s*/gravar\s+(\S+)\s*\n(.*)", re.S)

def chat(msg, hist):
    m = PESQUISA.match(msg)
    if m: return pesquisar(m.group(1))
    m = GIT.match(msg)
    if m: return github_buscar(m.group(1))
    m = CMD.match(msg)
    if m: return "```\n" + bash(m.group(1)) + "\n```"
    m = LER.match(msg)
    if m: return ler_arquivo(m.group(1).strip())
    m = GRAVAR.match(msg)
    if m: return escrever_arquivo(m.group(1), m.group(2))
    if "build" in msg.lower() and "rodar" in msg.lower():
        return build_e_corrigir()
    # RAG simples: se a pergunta parece precisar de dados atuais, pesquisa antes
    if any(k in msg.lower() for k in ["mais recente", "ultima versao", "hoje", "2026", "lei", "novidade"]):
        ctx = pesquisar(msg)
        return llm(f"Use estes resultados web ATUAIS para responder (cite os links completos):\n{ctx}\n\nPergunta: {msg}")
    return llm(msg)

# ---------------- Interface ----------------
CSS = """
body {background:#0b0f1a;}
.gradio-container {max-width:1100px !important; font-family:'Inter',sans-serif;}
h1 {background:linear-gradient(90deg,#7c3aed,#06b6d4); -webkit-background-clip:text; color:transparent;}
button.primary {background:linear-gradient(90deg,#7c3aed,#06b6d4) !important; border:none !important;}
"""

with gr.Blocks(title="GhostAI", css=CSS, theme=gr.themes.Soft()) as app:
    gr.Markdown("# 🛠️ GhostAI — Corretor Autonomo Java 17 / SDK 34")
    gr.Markdown("Agente duplo (Qwen2.5-Coder-7B + DeepSeek-Coder-6.7B) com pesquisa web (SearXNG/DuckDuckGo), GitHub, memoria permanente e shell Linux.")
    with gr.Tab("💬 Chat"):
        gr.ChatInterface(fn=chat,
            examples=["/pesquisa Android SDK 34 breaking changes",
                      "/github sketchware pro java 17",
                      "/cmd ls -la",
                      "Corrija o arquivo main/build.gradle",
                      "rode o build e corrija os erros"])
    with gr.Tab("📦 Projeto"):
        up = gr.File(label="ZIP do Sketchware Pro", file_types=[".zip"])
        btn_up = gr.Button("Extrair projeto", variant="primary")
        out_up = gr.Markdown()
        btn_up.click(subir_zip, up, out_up)
        with gr.Row():
            b1 = gr.Button("📂 Listar arquivos"); b2 = gr.Button("🔧 Corrigir p/ Java 17+SDK34", variant="primary")
            b3 = gr.Button("🏗️ Build + corrigir erros"); b4 = gr.Button("⬇️ Gerar ZIP corrigido")
        out_proj = gr.Markdown()
        zip_out = gr.File(label="Download do codigo corrigido")
        b1.click(listar_arquivos, None, out_proj)
        b2.click(corrigir_projeto, None, out_proj)
        b3.click(build_e_corrigir, None, out_proj)
        b4.click(gerar_zip, None, zip_out)

if __name__ == "__main__":
    app.launch(share=True, debug=False)
