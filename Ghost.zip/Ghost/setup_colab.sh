#!/usr/bin/env bash
# Setup completo no Google Colab (GPU T4): Ollama + 2 modelos + SearXNG + Agente
set -e

echo "== 1. Ollama =="
curl -fsSL https://ollama.com/install.sh | sh
nohup ollama serve > ollama.log 2>&1 &
sleep 8

echo "== 2. Baixando modelos (demora, ~10GB total) =="
ollama pull qwen2.5-coder:7b &
P1=$!
ollama pull deepseek-coder:6.7b &
P2=$!
wait $P1 $P2

echo "== 3. Criando modelos personalizados =="
ollama create qwen-sketchware -f modelos/Modelfile.qwen
ollama create deepseek-fix   -f modelos/Modelfile.deepseek

echo "== 4. SearXNG (API JSON na porta 8888, config do seu api.txt) =="
pip install -q searxng 2>/dev/null || true
if ! command -v searxng-run >/dev/null 2>&1; then
  git clone --depth 1 https://github.com/searxng/searxng.git /opt/searxng || true
  pip install -q -r /opt/searxng/requirements.txt || true
fi
mkdir -p /etc/searxng
cat > /etc/searxng/settings.yml <<'EOF'
use_default_settings: true
general:
  debug: false
  instance_name: "SearXNG Local"
search:
  safe_search: 0
  autocomplete: "duckduckgo"
  formats: [html, json, csv, rss]
server:
  secret_key: "1d218da5b487fd283d3c2f6013a8b7da47688294fc4e64ee8d8f17fd50190b23"
  bind_address: "127.0.0.1"
  port: 8888
  limiter: false
  image_proxy: true
EOF
nohup python -m searx.webapp > searx.log 2>&1 &

echo "== 5. Dependencias do agente =="
pip install -q gradio requests

echo "== 6. Teste da API SearXNG =="
sleep 5
curl -s "http://127.0.0.1:8888/search?q=gatos&format=json" | head -c 300 || echo "SearXNG ainda subindo..."

echo "== Pronto! Rode: python agente.py =="
