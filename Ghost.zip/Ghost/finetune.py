# -*- coding: utf-8 -*-
"""
Fine-tuning QLoRA do Qwen2.5-Coder-7B no Google Colab (GPU T4)
Objetivo: especializar o modelo em correção de código Android/Java (Sketchware Pro -> Java 17 + SDK 34)
Executar CELULA POR CELULA no Colab.
"""

# ============================================================
# CELULA 1 - Instalacao
# ============================================================
# !pip install -q "unsloth[colab-new] @ git+https://github.com/unslothai/unsloth.git"
# !pip install -q --no-deps trl peft accelerate bitsandbytes datasets

# ============================================================
# CELULA 2 - Carregar modelo em 4-bit (cabe na T4)
# ============================================================
from unsloth import FastLanguageModel
import torch

MAX_SEQ = 4096
model, tokenizer = FastLanguageModel.from_pretrained(
    model_name="unsloth/Qwen2.5-Coder-7B-Instruct-bnb-4bit",
    max_seq_length=MAX_SEQ,
    dtype=None,
    load_in_4bit=True,
)

model = FastLanguageModel.get_peft_model(
    model,
    r=32,
    target_modules=["q_proj", "k_proj", "v_proj", "o_proj",
                    "gate_proj", "up_proj", "down_proj"],
    lora_alpha=32,
    lora_dropout=0,
    bias="none",
    use_gradient_checkpointing="unsloth",
    random_state=42,
)

# ============================================================
# CELULA 3 - Dataset de treino
# Formato: JSONL com {"instruction": "...", "input": "...", "output": "..."}
# Gere exemplos assim (quantos quiser, ideal 500+):
#
# {"instruction": "Corrija este build.gradle para Java 17 e SDK 34",
#  "input": "compileSdkVersion 28 ... sourceCompatibility 1.8 ...",
#  "output": "android { namespace '...' compileSdk 34 ... JavaVersion.VERSION_17 ... }"}
#
# Voce pode gerar esses exemplos a partir do proprio codigo do Sketchware Pro
# e de diffs reais de migracao (o script gerar_dataset.py faz isso).
# ============================================================
from datasets import load_dataset

PROMPT = """### Instrucao:
{instruction}

### Codigo/Entrada:
{input}

### Resposta:
{output}"""

def fmt(ex):
    return {"text": PROMPT.format(**ex) + tokenizer.eos_token}

dataset = load_dataset("json", data_files="dataset_sketchware.jsonl", split="train")
dataset = dataset.map(fmt)

# ============================================================
# CELULA 4 - Treino
# ============================================================
from trl import SFTTrainer
from transformers import TrainingArguments

trainer = SFTTrainer(
    model=model,
    tokenizer=tokenizer,
    train_dataset=dataset,
    dataset_text_field="text",
    max_seq_length=MAX_SEQ,
    args=TrainingArguments(
        per_device_train_batch_size=2,
        gradient_accumulation_steps=8,
        warmup_steps=20,
        max_steps=300,              # aumente para 1000+ com mais dados
        learning_rate=2e-4,
        fp16=not torch.cuda.is_bf16_supported(),
        bf16=torch.cuda.is_bf16_supported(),
        logging_steps=10,
        optim="adamw_8bit",
        output_dir="checkpoints",
        save_strategy="steps",
        save_steps=100,
    ),
)
trainer.train()

# ============================================================
# CELULA 5 - Exportar para Ollama (GGUF)
# ============================================================
model.save_pretrained_gguf("qwen-sketchware-gguf", tokenizer, quantization_method="q4_k_m")
# Baixe a pasta qwen-sketchware-gguf, depois no seu PC:
#   echo 'FROM ./qwen-sketchware-gguf/unsloth.Q4_K_M.gguf' > Modelfile
#   ollama create qwen-sketchware -f Modelfile
# Para usar o fine-tune DENTRO do Colab com o Ollama, veja o notebook agente.ipynb
print("Fine-tuning concluido e GGUF exportado.")
